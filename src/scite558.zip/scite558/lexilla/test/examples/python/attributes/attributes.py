# attributes=20
s = "thing thing".findall("thing")
a.very.complicated.expression.findall("test")
# fake out.
b.very.complicated.expression.
    findall("test2")
c.very.complicated.expression. \
    findall("test3")
d.very.complicated.expression.\
    findall("test4")
@staticmethod.attrtest
@staticmethod.
attrtest
@staticmethod. \
attrtest
@staticmethod.\
attrtest
