# ugly code to demonstrate multiline string.
`Hello
World` <- function(x, y, z) {
	print(x);
	print(y);
	print(z);
}
`Hello\nWorld`("Hello\nMoon!", "Hello
Venus", 'Hello\
Mars');
